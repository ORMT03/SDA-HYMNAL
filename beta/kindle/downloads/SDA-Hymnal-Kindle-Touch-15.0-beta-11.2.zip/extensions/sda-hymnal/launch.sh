#!/bin/sh
set -eu
ROOT=$(CDPATH='' cd "$(dirname "$0")" && pwd -P)
PYTHON=/mnt/us/python3/bin/python3.9
LOCK=/tmp/sda-hymnal-native.lock
if ! mkdir "$LOCK" 2>/dev/null; then
 if [ -f "$LOCK/pid" ] && kill -0 "$(cat "$LOCK/pid")" 2>/dev/null; then exit 0; fi
 rm -rf "$LOCK"; mkdir "$LOCK"
fi
echo $$ > "$LOCK/pid"
mkdir -p "$ROOT/state/jobs" "$ROOT/cache"
FBINK=/mnt/us/koreader/fbink
[ -x "$FBINK" ] || FBINK=/mnt/us/extensions/companion/bin/fbink
CHILD=
cleanup() {
 [ -z "$CHILD" ] || kill "$CHILD" 2>/dev/null || true
 lipc-set-prop com.lab126.powerd preventScreenSaver 0 >/dev/null 2>&1 || true
 lipc-set-prop com.lab126.pillow interrogatePillow '{"pillowId":"default_status_bar","function":"nativeBridge.showMe();"}' >/dev/null 2>&1 || true
 if [ -f "$LOCK/framebuffer.raw" ]; then cat "$LOCK/framebuffer.raw" > /dev/fb0; "$FBINK" -q -s >/dev/null 2>&1 || true; fi
 rm -rf "$LOCK"
}
trap cleanup EXIT HUP INT TERM
if [ ! -x "$PYTHON" ] || [ ! -x "$FBINK" ]; then eips 0 2 'SDA Hymnal needs Kindle Python 3 and FBInk.'; exit 1; fi
cat /dev/fb0 > "$LOCK/framebuffer.raw"
# A direct native process; no KOReader app, plugin, or framework stop.
while :; do
 if ! "$PYTHON" "$ROOT/bootstrap.py" > "$ROOT/state/launch-path.txt" 2> "$ROOT/state/launch-error.log"; then eips 0 2 'SDA Hymnal files incomplete. Recopy installer.'; exit 1; fi
 APP=$(cat "$ROOT/state/launch-path.txt")
 chmod +x "$APP/bin/hymnal" "$APP/bin/verovio"
 "$APP/bin/hymnal" "$ROOT" "$APP" "$FBINK" >> "$ROOT/state/native.log" 2>&1 &
 CHILD=$!
 CODE=0; wait "$CHILD" || CODE=$?
 CHILD=
 [ "$CODE" -eq 75 ] || break
done
