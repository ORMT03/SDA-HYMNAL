#!/usr/bin/env python3
"""SDA Hymnal K5: native data, rendering, and verified incremental updates."""
import argparse
import contextlib
import copy
import fcntl
import hashlib
import html
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import resource
import shutil
import ssl
import subprocess
import tempfile
import time
import unicodedata
import urllib.parse
import urllib.request
import zipfile
import xml.etree.ElementTree as ET

VERSION = '15.0 beta 8'
BASE = 'https://ormt03.github.io/SDA-HYMNAL/'
DEFAULTS = dict(language='english', view='score', default_language='last', default_view='last',
                smart=False, allow_exports=False, font_size=18, list_behavior='top', keep_awake=False,
                offline_language='both', offline_scores=True,
                view_options=dict(chords=False, lyrics=True, credits=True, heading=True, copyright=True),
                share_options=dict(chords=False, lyrics=True, credits=True, heading=True, copyright=True))
LANGUAGES = ('english', 'spanish', 'both')

def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return copy.deepcopy(default)

def atomic_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.part-' + str(os.getpid()))
    with temp.open('w', encoding='utf-8') as out:
        json.dump(value, out, ensure_ascii=False, separators=(',', ':'))
        out.flush(); os.fsync(out.fileno())
    os.replace(str(temp), str(path))

def digest_file(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(131072), b''):
            digest.update(chunk)
    return digest.hexdigest()

def safe_relative(path):
    if not isinstance(path, str) or not path or '\\' in path or '\x00' in path:
        raise ValueError('Invalid file path')
    parts = PurePosixPath(path)
    if parts.is_absolute() or '..' in parts.parts or str(parts) != path:
        raise ValueError('Invalid file path')
    return path

def normalize(text):
    return re.sub(r'[^\w\s]', ' ', ''.join(c for c in unicodedata.normalize('NFD', str(text))
                                         if unicodedata.category(c) != 'Mn').lower())

def lyrics_text(song):
    text = song.get('content', '')
    for number in range(1, 11):
        text = text.replace(str(number) + '.', 'Verse ' + str(number))
    return re.sub('CHORUS:', 'Chorus', text, flags=re.I)

def score_metadata(root, song):
    fields = {e.get('name'): (e.text or '').strip() for e in root.findall('.//miscellaneous-field')}
    def creator(kind):
        return next(((e.text or '').strip() for e in root.findall('.//creator') if e.get('type') == kind), '')
    right = [' '.join(filter(None, [fields.get('tune-name'), fields.get('metrical-pattern')])),
             fields.get('tune-source', ''), creator('composer')]
    if creator('arranger'): right.append('Harm. by ' + creator('arranger'))
    left = [fields.get('scripture-reference', ''), creator('poet') or creator('lyricist')]
    if creator('translator'): left.append('Tr. by ' + creator('translator'))
    rights = '\n'.join(' '.join((n.text or '').strip() for n in e.findall('credit-words')) for e in root.findall('credit')
                       if e.findtext('credit-type') == 'rights')
    return dict(title=root.findtext('work/work-title') or song['title'],
                left=list(filter(None, left)), right=list(filter(None, right)),
                footer=rights or fields.get('category', ''))

def render_limits():
    # Limit each renderer child independently; the native interface stays small.
    resource.setrlimit(resource.RLIMIT_AS, (160*1024*1024,160*1024*1024))
    resource.setrlimit(resource.RLIMIT_CPU,(90,95))

class Hymnal:
    def __init__(self, root, app_dir=None, progress=None):
        self.root = Path(root).resolve()
        self.state = self.root / 'state'; self.store = self.root / 'store'
        self.cache = self.root / 'cache'; self.releases = self.root / 'releases'
        for directory in [self.state, self.store, self.cache, self.releases]:
            directory.mkdir(parents=True, exist_ok=True)
        self.current = read_json(self.root / 'current.json', {})
        self.config = read_json(self.root / 'config.json', {})
        self.base = self.config.get('base_url', BASE)
        self.update_url = urllib.parse.urljoin(self.base, 'beta/kindle/release.json')
        self.website_url = urllib.parse.urljoin(self.base, 'beta/release.json')
        self.app_dir = Path(app_dir) if app_dir else self.releases / self.current.get('app', {}).get('id', 'none')
        self.progress = progress or (lambda *args, **kwargs: None)
        self._songs = None

    @contextlib.contextmanager
    def lock(self):
        with (self.state / 'write.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            try: yield
            finally: fcntl.flock(lock, fcntl.LOCK_UN)

    def settings(self):
        saved = read_json(self.state / 'settings.json', {})
        result = copy.deepcopy(DEFAULTS)
        for key, value in saved.items():
            if key in result:
                if isinstance(result[key], dict) and isinstance(value, dict): result[key].update(value)
                else: result[key] = value
        return result

    def save_settings(self, changes):
        result = self.settings()
        for key, value in changes.items():
            if key not in DEFAULTS: continue
            if isinstance(DEFAULTS[key], dict):
                if not isinstance(value, dict): raise ValueError('Invalid score options')
                for field in DEFAULTS[key]:
                    if field in value: result[key][field] = bool(value[field])
            else: result[key] = value
        for field in ['language', 'offline_language']:
            if result[field] not in LANGUAGES: raise ValueError('Invalid language')
        if result['default_language'] not in ('last',) + LANGUAGES: raise ValueError('Invalid default language')
        if result['default_view'] not in ('last', 'score', 'lyrics') or result['view'] not in ('score', 'lyrics'):
            raise ValueError('Invalid view')
        if result['list_behavior'] not in ('top', 'remember', 'sticky'): raise ValueError('Invalid list option')
        result['font_size'] = max(12, min(40, int(result['font_size'])))
        for field in ['smart', 'keep_awake', 'offline_scores', 'allow_exports']: result[field] = bool(result[field])
        with self.lock(): atomic_json(self.state / 'settings.json', result)
        return result

    def trusted_url(self, url):
        parsed, origin = urllib.parse.urlsplit(url), urllib.parse.urlsplit(self.base)
        if parsed.scheme != 'https' and not (self.config.get('allow_local_http') and
                parsed.hostname in ('127.0.0.1', 'localhost') and parsed.scheme == 'http'):
            raise ValueError('Updates require HTTPS')
        clean = urllib.parse.unquote(parsed.path)
        if (parsed.netloc != origin.netloc or not clean.startswith(origin.path) or
                '..' in PurePosixPath(clean).parts or parsed.username or parsed.password or parsed.fragment):
            raise ValueError('Update URL is outside this hymnal')
        return url

    def fetch(self, url, maximum=4000000, timeout=20):
        self.trusted_url(url)
        try:
            import certifi
            context = ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            context = ssl.create_default_context()
        request = urllib.request.Request(url, headers={'User-Agent': 'SDA-Hymnal-Kindle/' + VERSION,
                                                       'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(request, timeout=timeout, context=context) as response:
            self.trusted_url(response.geturl())
            data = response.read(maximum + 1)
        if len(data) > maximum: raise ValueError('Download exceeded its allowed size')
        return data

    def fetch_json(self, url):
        value = json.loads(self.fetch(url).decode('utf-8'))
        if not isinstance(value, dict): raise ValueError('Invalid release')
        return value

    def validate_files(self, release, kind):
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,119}', str(release.get('id', ''))) or '..' in release['id']:
            raise ValueError('Invalid release identifier')
        if not isinstance(release.get('files'), list) or not release['files']:
            raise ValueError('Empty release')
        seen = set()
        for entry in release['files']:
            path = safe_relative(entry['path'])
            if path in seen or not re.fullmatch('[0-9a-f]{64}', entry.get('sha256', '')):
                raise ValueError('Invalid release file')
            if not isinstance(entry.get('bytes'), int) or not 0 <= entry['bytes'] <= 40000000:
                raise ValueError('Invalid file size')
            self.trusted_url(entry['url']); seen.add(path)
            if kind == 'data' and path not in ('catalogs/songs.json', 'catalogs/songs_es.json',
                    'catalogs/song_mapping.json', 'catalogs/scores.json') and not (
                    path.startswith('musicxml/English/') or path.startswith('musicxml/Spanish/')):
                raise ValueError('Unexpected hymn content')
        required = ['backend.py', 'bin/hymnal', 'svg_to_png.lua', 'qr.lua', 'bin/verovio', 'bin/png-scale', 'fonts/Bravura.otf', 'fonts/Leipzig.ttf', 'resources.zip'] if kind == 'app' else [
            'catalogs/songs.json', 'catalogs/songs_es.json', 'catalogs/scores.json', 'catalogs/song_mapping.json']
        if not all(path in seen for path in required): raise ValueError('Incomplete release')
        return release

    def website_data(self, release):
        files = []
        allowed = {'../songs.json': 'catalogs/songs.json', '../songs_es.json': 'catalogs/songs_es.json',
                   '../song_mapping.json': 'catalogs/song_mapping.json', 'scores.json': 'catalogs/scores.json'}
        for entry in release.get('files', []):
            path = entry.get('path', '')
            if path in allowed or (path.startswith(('musicxml/English/', 'musicxml/Spanish/')) and path.endswith('.musicxml')):
                files.append(dict(path=allowed.get(path, path), sha256=entry['sha256'], bytes=entry['bytes'],
                                  url=urllib.parse.urljoin(self.website_url, urllib.parse.quote(path, safe='/'))))
        full = release.get('full')
        if full: full = dict(full, url=urllib.parse.urljoin(self.website_url, full['url']))
        collections=[dict(selection=c['selection'],full=dict(c['full'],url=urllib.parse.urljoin(self.website_url,c['full']['url']))) for c in release.get('collections',[])]
        return self.validate_files(dict(id=release['id'], version=release['version'], files=files, archive=full,collections=collections), 'data')

    def check(self):
        """Checking only retrieves manifests; it cannot install or fetch content."""
        errors = []; pending = {}; current = read_json(self.root / 'current.json', {})
        try:
            manifest = self.fetch_json(self.update_url)
            if manifest.get('schema') != 1 or manifest.get('platform')!='kindle-touch-k5': raise ValueError('Unsupported Kindle release')
            pending['app'] = self.validate_files(manifest['app'], 'app')
            if manifest.get('data'): pending['data'] = self.validate_files(manifest['data'], 'data')
        except Exception as error: errors.append('Kindle update check: ' + str(error))
        try:
            website = self.website_data(self.fetch_json(self.website_url))
            if not pending.get('data') or sorted((e['path'],e['sha256'])for e in pending['data']['files'])!=sorted((e['path'],e['sha256'])for e in website['files']): pending['data'] = website
        except Exception as error: errors.append('Hymnal update check: ' + str(error))
        if not pending:
            result=dict(available=False, offline=True, message='You’re offline. Unable to check for updates.', details=errors)
            atomic_json(self.state/'check.json',result)
            return result
        def changed(kind, item):
            installed=current.get(kind,{})
            if kind=='data':
                fingerprint=lambda entries:sorted((e['path'],e['sha256']) for e in entries)
                return fingerprint(installed.get('available_files',installed.get('files',[])))!=fingerprint(item['files'])
            return installed.get('id')!=item['id']
        available = any(changed(kind,item) for kind,item in pending.items())
        atomic_json(self.state / 'pending.json', pending)
        versions = [item['version'] for kind, item in pending.items() if changed(kind,item)]
        result = dict(available=available, offline=False,
                      message='Update available: ' + ' / '.join(versions) + '.' if available else 'You’re up to date.',
                      app_version=pending.get('app', current.get('app', {})).get('version'),
                      data_version=pending.get('data', current.get('data', {})).get('version'), details=errors)
        atomic_json(self.state / 'check.json', result)
        return result

    def blob_path(self, entry): return self.store / entry['sha256']

    def have(self, entry):
        path = self.blob_path(entry)
        return path.is_file() and path.stat().st_size == entry['bytes'] and digest_file(path) == entry['sha256']

    def put_blob(self, entry, data):
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise ValueError('Verification failed: ' + entry['path'])
        path = self.blob_path(entry); temp = path.with_suffix('.part')
        with temp.open('wb') as out: out.write(data); out.flush(); os.fsync(out.fileno())
        os.replace(str(temp), str(path))

    def selected_data(self, release, settings):
        def wanted(entry):
            path = entry['path']; language = settings['offline_language']
            if path == 'catalogs/songs.json': return language != 'spanish'
            if path == 'catalogs/songs_es.json': return language != 'english'
            if path.startswith('musicxml/'):
                return settings['offline_scores'] and (language == 'both' or path.startswith('musicxml/' + language.title() + '/'))
            return True
        return dict(release, files=[e for e in release['files'] if wanted(e)], available_files=release['files'],
                    selection=dict(language=settings['offline_language'], scores=settings['offline_scores']))

    def fetch_entries(self, release, files, pack=None):
        missing = [e for e in files if not self.have(e)]
        if missing and pack and pack.get('bytes', 0) < sum(e['bytes'] for e in missing):
            try:
                self.progress('Downloading the collection…', 10)
                archive = self.fetch(pack['url'], maximum=pack['bytes'], timeout=120)
                if len(archive) != pack['bytes'] or hashlib.sha256(archive).hexdigest() != pack['sha256']:
                    raise ValueError('Archive verification failed')
                with zipfile.ZipFile(io.BytesIO(archive)) as zipped:
                    for entry in missing:
                        name = 'files/' + entry['sha256']
                        try:
                            info = zipped.getinfo(name)
                            if info.file_size != entry['bytes']: raise ValueError('Invalid archived size')
                            self.put_blob(entry, zipped.read(name))
                        except KeyError: pass
            except Exception:
                # Verified individual files resume a missing or interrupted ZIP.
                pass
        for index, entry in enumerate(missing):
            if not self.have(entry): self.put_blob(entry, self.fetch(entry['url'], maximum=entry['bytes'], timeout=60))
            self.progress('Saving required files…', 15 + int(70 * (index + 1) / max(1, len(missing))))

    def download(self, refresh=True):
        if refresh: self.check()
        pending = read_json(self.state / 'pending.json', {})
        if not pending: raise ValueError('Connect to check for an update first.')
        with self.lock():
            previous = read_json(self.root / 'current.json', {})
            next_state = copy.deepcopy(previous)
            app = pending.get('app', previous.get('app'))
            data = pending.get('data')
            if data is None and previous.get('data'):
                data = dict(previous['data'], files=previous['data'].get('available_files', previous['data']['files']))
            if not app or not data: raise ValueError('The complete app and hymnal manifest are required.')
            selected = self.selected_data(data, self.settings())
            self.fetch_entries(app, app['files'], app.get('full'))
            app_path = self.releases / app['id']
            if not app_path.is_dir():
                stage = self.releases / (app['id'] + '.partial'); stage.mkdir(exist_ok=True)
                for entry in app['files']:
                    target = stage / safe_relative(entry['path']); target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(str(self.blob_path(entry)), str(target))
                    if entry['path'].startswith('bin/'): target.chmod(0o755)
                with zipfile.ZipFile(str(stage/'resources.zip')) as resource_zip:
                    total=0
                    for info in resource_zip.infolist():
                        if info.is_dir():continue
                        relative=safe_relative(info.filename);total+=info.file_size
                        if total>20000000:raise ValueError('Invalid engraving resource size')
                        target=stage/'resources'/relative;target.parent.mkdir(parents=True,exist_ok=True)
                        target.write_bytes(resource_zip.read(info.filename))
                for entry in app['files']:
                    if entry['path'].endswith('.py'): compile((stage / entry['path']).read_text(encoding='utf-8'), entry['path'], 'exec')
                os.replace(str(stage), str(app_path))
            selection = selected['selection']
            pack = next((p['full'] for p in data.get('collections', []) if p['selection'] == selection), None)
            if pack is None and selection == dict(language='both', scores=True): pack = data.get('archive')
            self.fetch_entries(data, selected['files'], pack)
            if not all(self.have(e) for e in app['files'] + selected['files']): raise ValueError('Download is incomplete')
            next_state = dict(schema=1, app=app, data=selected, saved_at=time.time())
            if previous.get('app'): atomic_json(self.state / 'recovery-app.json', previous['app'])
            atomic_json(self.root / 'current.json', next_state)
            self.current = next_state; self._songs=None
            self.progress('All files verified. Applying the update…', 100)
            try: self._cleanup()
            except OSError: pass
        return dict(restart=True, message='Saved offline. The app will reopen to apply the update.')

    def entry(self, path, available=False):
        data = self.current.get('data', {})
        return next((e for e in data.get('available_files' if available else 'files', []) if e['path'] == path), None)

    def content_json(self, path, default=None):
        entry = self.entry(path)
        return read_json(self.blob_path(entry), default) if entry else copy.deepcopy(default)

    def songs(self):
        if self._songs is None:
            self._songs = []
            for language, filename in [('english', 'songs.json'), ('spanish', 'songs_es.json')]:
                for song in self.content_json('catalogs/' + filename, []): self._songs.append(dict(song, language=language))
        return self._songs

    def find_song(self, language, number):
        return next((s for s in self.songs() if s['language'] == language and s['number'] == str(number).zfill(3)), None)

    def search(self, request):
        settings = self.settings(); language = request.get('language', settings['language'])
        query = normalize(request.get('query', '')).strip(); smart = request.get('smart', settings['smart'])
        results = []
        for song in self.songs():
            if language != 'both' and song['language'] != language: continue
            title, number = normalize(song['title']), song['number']; rank = 0
            if not query: rank = 1
            elif query.isdigit(): rank = 200 if number == query.zfill(3) else 0
            elif not smart: rank = 100 if query in title else 0
            else:
                words = query.split(); lyrics = normalize(song.get('content', ''))
                rank = (80 if query in title else 0) + (40 if query in lyrics else 0)
                rank += sum((20 if word in title else 0) + (4 if word in lyrics else 0) for word in words)
            if rank: results.append((rank, song))
        results.sort(key=lambda row: (-row[0], row[1]['language'], row[1]['number']))
        grouped = bool(query and language == 'both')
        ordered = []
        if grouped:
            by_key = {(s['language'], s['number']): s for s in self.songs()}
            links = {}
            def numbers(value):
                values = value if isinstance(value, list) else [value]
                return [str(n).zfill(3) for n in values if n is not None and str(n).strip()]
            for pair in self.content_json('catalogs/song_mapping.json', []):
                english = [('english', n) for n in numbers(pair.get('english', []))]
                spanish = [('spanish', n) for n in numbers(pair.get('spanish', []))]
                for first in english:
                    for second in spanish:
                        if first in by_key and second in by_key:
                            links.setdefault(first, set()).add(second)
                            links.setdefault(second, set()).add(first)
            shown = set()
            for _, song in results:
                first = (song['language'], song['number'])
                if first in shown: continue
                group_keys = [first] + sorted(links.get(first, ()), key=lambda key: (key[0], key[1]))
                group = [by_key[key] for key in group_keys]
                shown.update(group_keys)
                for index, member in enumerate(group):
                    ordered.append(dict(number=member['number'], title=member['title'],
                                        language=member['language'], group_start=index == 0))
        else:
            ordered = [dict(number=s['number'], title=s['title'], language=s['language']) for _, s in results]
        return dict(songs=ordered, count=len(ordered), settings=settings, grouped=grouped)

    def obtain_content(self, path):
        entry = self.entry(path, available=True) or self.entry(path)
        if not entry: raise ValueError('No score file is available for this hymn.')
        if self.have(entry): return self.blob_path(entry)
        try:
            data = self.fetch(entry['url'], maximum=entry['bytes'])
            if hashlib.sha256(data).hexdigest() != entry['sha256']: raise ValueError('Newer file on server')
        except Exception:
            archive = self.current.get('data', {}).get('archive')
            if not archive: raise
            zipped = self.fetch(archive['url'], maximum=archive['bytes'], timeout=120)
            if hashlib.sha256(zipped).hexdigest() != archive['sha256']: raise ValueError('Archive verification failed')
            with zipfile.ZipFile(io.BytesIO(zipped)) as source: data = source.read('files/' + entry['sha256'])
        # A viewed online score may be reused; selection cleanup can remove it later.
        self.put_blob(entry, data)
        return self.blob_path(entry)

    def hymn(self, request):
        song = self.find_song(request['language'], request['number'])
        if song and request.get('view') in ('score','lyrics'):
            self.save_settings(dict(view=request['view']))
        if not song: raise ValueError('This hymn’s language is not saved. Change the offline selection in Settings.')
        mapping = self.content_json('catalogs/scores.json', {})
        score = mapping.get(song['language'] + ':' + song['number'])
        fifths, minor = None, False
        entry = self.entry(score, available=True) if score else None
        if entry and self.blob_path(entry).exists():
            root = ET.parse(str(self.blob_path(entry))).getroot()
            fifths = int(root.findtext('.//key/fifths', '0')); minor = root.findtext('.//key/mode') == 'minor'
        major = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B']
        tonic = ((fifths or 0) * 7 + (9 if minor else 0)) % 12
        keys = []
        for note, name in enumerate(major):
            offset = (note - tonic + 6) % 12 - 6
            keys.append(dict(name=name + (' minor' if minor else ''), offset=offset, original=offset == 0))
        return dict(song=song, lyrics=lyrics_text(song), has_score=bool(score), original_key=major[tonic] + (' minor' if minor else '') if fifths is not None else None, keys=keys if fifths is not None else [])

    def _draw_metadata(self, image, metadata, song, options, first, last):
        from PIL import ImageDraw, ImageFont
        draw = ImageDraw.Draw(image); width, height = image.size
        fonts = Path(self.config.get('koreader_dir', '/mnt/us/koreader')) / 'fonts/noto'
        def font(size, bold=False):
            for filename in [('NotoSerif-Bold.ttf' if bold else 'NotoSerif-Regular.ttf'), 'NotoSans-Regular.ttf']:
                try: return ImageFont.truetype(str(fonts / filename), size)
                except OSError: pass
            return ImageFont.load_default()
        def text_width(text, face):
            box = draw.textbbox((0, 0), text, font=face) if hasattr(draw, 'textbbox') else (0, 0) + draw.textsize(text, font=face)
            return box[2] - box[0]
        if first:
            if options['heading']:
                face = font(30, True); title = metadata['title']
                while text_width(title, face) > width - 160 and len(title) > 10:
                    face = font(max(16, getattr(face, 'size', 30) - 1), True)
                    if getattr(face, 'size', 16) <= 16: break
                draw.text(((width - text_width(title, face))/2, 15), title, font=face, fill='black')
                draw.text((width - 55, 15), str(int(song['number'])), font=font(30, True), fill='black')
            if options['credits']:
                face = font(13)
                for index, line in enumerate(metadata['left']): draw.text((35, 70+index*16), line, font=face, fill='black')
                for index, line in enumerate(metadata['right']): draw.text((width-35-text_width(line, face), 70+index*16), line, font=face, fill='black')
        if last and options['copyright'] and metadata['footer']:
            face = font(13); lines = metadata['footer'].splitlines()
            for index, line in enumerate(lines): draw.text(((width-text_width(line, face))/2, height-35-16*(len(lines)-1-index)), line, font=face, fill='black')
        return image

    def render(self, request):
        song = self.find_song(request['language'], request['number'])
        if not song: raise ValueError('This hymn is not saved in the selected language.')
        settings = self.settings(); scope = request.get('scope', 'view')
        if scope not in ('view', 'share'): raise ValueError('Invalid score settings')
        options = settings[scope + '_options']; offset = int(request.get('offset', 0))
        if not -12 <= offset <= 12: raise ValueError('Invalid transposition')
        mapping = self.content_json('catalogs/scores.json', {}); score = mapping.get(song['language'] + ':' + song['number'])
        identity = dict(hymn=song['language']+song['number'], offset=offset, options=options,
                        data=self.current.get('data', {}).get('id'), app=self.current.get('app', {}).get('id'))
        cache_id = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()[:24]
        folder = self.cache / 'scores' / cache_id; pdf = folder / 'score.pdf'
        if pdf.is_file() and not request.get('refresh'): return dict(pdf=str(pdf), images=[str(p) for p in sorted(folder.glob('*.png')) if p.name != 'display.png'], image_fallback=not bool(score), cached=True,hymn=read_json(folder/'hymn.json',self.hymn(request)))
        folder.mkdir(parents=True, exist_ok=True)
        from PIL import Image
        pngs = []
        if score:
            source = self.obtain_content(score); tree = ET.parse(str(source)); root = tree.getroot()
            metadata = score_metadata(root, song)
            if not options['chords']:
                for parent in root.iter():
                    for node in list(parent):
                        if node.tag == 'harmony': parent.remove(node)
            if not options['lyrics']:
                for parent in root.iter():
                    for node in list(parent):
                        if node.tag == 'lyric': parent.remove(node)
            sanitized = folder / 'score.musicxml'; tree.write(str(sanitized), encoding='utf-8', xml_declaration=True)
            prefix = folder / 'engraved'
            command = [str(self.app_dir / 'bin/verovio'), '-f', 'xml', '-a', '-r', str(self.app_dir / 'resources'),
                       '--font', 'Bravura', '--header', 'none', '--footer', 'none', '--breaks', 'encoded',
                       '--page-width', '2159', '--page-height', '2794', '--page-margin-top', '230',
                       '--page-margin-bottom', '100', '--page-margin-left', '65', '--page-margin-right', '65',
                       '--min-last-justification', '0', '--scale', '50', '--transpose', str(offset) if offset else 'P1', '-o', str(prefix), str(sanitized)]
            self.progress('Engraving the score on your Kindle…', 15)
            completed = subprocess.run(command, preexec_fn=render_limits, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
            (folder / 'engraving.log').write_bytes(completed.stderr)
            if completed.returncode: raise ValueError('The score could not be engraved. ' + completed.stderr.decode('utf-8', 'replace')[-250:])
            svgs = sorted(folder.glob('engraved*.svg'))
            if not svgs: raise ValueError('The engraving engine produced no pages.')
            koreader = Path(self.config.get('koreader_dir', '/mnt/us/koreader'))
            for index, svg in enumerate(svgs):
                png = svg.with_suffix('.png')
                completed = subprocess.run([str(koreader/'luajit'), str(self.app_dir/'svg_to_png.lua'),
                                            str(svg), str(png), '1275', '1650'], cwd=str(koreader),
                                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90, preexec_fn=render_limits)
                if completed.returncode or not png.is_file():
                    raise ValueError('The native image renderer could not display this score: ' + completed.stderr.decode('utf-8','replace')[-250:])
                with Image.open(str(png)) as im:
                    white = Image.new('RGB', (1275, 1650), 'white'); converted = im.convert('RGBA').resize((1275,1650), Image.Resampling.LANCZOS if hasattr(Image,'Resampling') else Image.LANCZOS)
                    white.paste(converted, (0, 0), converted)
                    self._draw_metadata(white, metadata, song, options, index == 0, index == len(svgs)-1)
                    white.save(str(png)); white.close()
                pngs.append(png)
                self.progress('Preparing page ' + str(index+1) + '…', 40+int(40*(index+1)/len(svgs)))
        else:
            # Images are fetched only for a requested hymn, never by offline downloads.
            count = max(1, int(song.get('pages', 1))); name = song['image']; base = name.rsplit('.',1)[0].replace('_Full','')
            names = [name] if count == 1 else [base+('_'+str(i) if i else '')+'.png' for i in range(count)]
            for index, name in enumerate(names):
                url = urllib.parse.urljoin(self.base, 'src/Hymnal.XF/Resources/Assets/MusicSheets/'+urllib.parse.quote(name))
                data = self.fetch(url, maximum=16000000, timeout=45)
                source_png=folder/('download-'+str(index)+'.png');source_png.write_bytes(data);del data
                scaled=folder/('scaled-'+str(index)+'.pgm')
                koreader=Path(self.config.get('koreader_dir','/mnt/us/koreader'))
                decoder=self.app_dir/'bin/png-scale'
                environment=dict(os.environ,LD_LIBRARY_PATH=str(koreader/'libs'))
                decoded=subprocess.run([str(decoder),str(koreader/'libs/libpng16.so.16'),str(source_png),str(scaled),'1170','1545'],env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90,preexec_fn=render_limits)
                if decoded.returncode or not scaled.is_file():raise ValueError('The sheet image could not be safely decoded. Saved lyrics remain available.')
                with Image.open(str(scaled)) as im:
                    # The decoded image is already small. Never expand the original PNG in Python.
                    paper=Image.new('RGB',(1275,1650),'white');paper.paste(im,((1275-im.width)//2,(1650-im.height)//2))
                    png=folder/('original-'+str(index)+'.png');paper.save(str(png));paper.close()
                source_png.unlink(missing_ok=True);scaled.unlink(missing_ok=True)
                pngs.append(png)
        pages = [Image.open(str(p)).convert('RGB') for p in pngs]
        try:
            temp = folder/'score.partial.pdf'
            pages[0].save(str(temp), 'PDF', resolution=150.0, save_all=True, append_images=pages[1:])
            os.replace(str(temp),str(pdf))
        finally:
            for page in pages: page.close()
        info=self.hymn(request);atomic_json(folder/'hymn.json',info)
        return dict(pdf=str(pdf), images=[str(p) for p in pngs], pages=len(pngs), image_fallback=not bool(score), cached=False,hymn=info)

    def share(self, request):
        song=self.find_song(request['language'],request['number'])
        if not song:raise ValueError('Hymn not found')
        view='lyrics' if request.get('view')=='lyrics' else 'score'
        query={'view':view}
        if view=='score':query['transpose']=str(max(-12,min(12,int(request.get('offset',0)))))
        url=urllib.parse.urljoin(self.base,'beta/')+'?'+urllib.parse.urlencode(query)+'#'+song['language']+'/'+song['number']
        return dict(url=url,title=song['number']+' - '+song['title'],view=view)

    def display(self, request):
        """Make a bounded viewport from an existing page, never re-engrave for zoom."""
        from PIL import Image
        path=Path(request['image']).resolve()
        if self.cache not in path.parents or not path.is_file(): raise ValueError('Invalid score image')
        zoom=max(100,min(400,int(request.get('zoom',100))))
        with Image.open(str(path)) as original:
            width=600*zoom//100; height=max(1,original.height*width//original.width)
            image=original.convert('RGB').resize((width,height),Image.Resampling.LANCZOS if hasattr(Image,'Resampling') else Image.LANCZOS)
        x=max(0,min(width-600,int(request.get('x',0))));y=max(0,min(max(0,height-672),int(request.get('y',0))))
        canvas=Image.new('RGB',(600,672),'white');crop=image.crop((x,y,min(x+600,width),min(y+672,height)))
        canvas.paste(crop,(0,0));target=self.cache/'display.png';canvas.save(str(target));raw=self.cache/'display.raw';raw.write_bytes(canvas.convert('L').tobytes());canvas.close();image.close()
        return dict(image=str(raw),x=x,y=y,max_x=max(0,width-600),max_y=max(0,height-672))

    def qr(self, request):
        result=self.share(request);koreader=Path(self.config.get('koreader_dir','/mnt/us/koreader'))
        target=self.cache/'share.pgm'
        completed=subprocess.run([str(koreader/'luajit'),str(self.app_dir/'qr.lua'),result['url'],str(target)],cwd=str(koreader),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,preexec_fn=render_limits)
        if completed.returncode: raise ValueError('Unable to prepare the sharing code.')
        from PIL import Image
        with Image.open(str(target)) as image:
            scale=480//image.width;size=image.width*scale
            qr=image.resize((size,size),Image.Resampling.NEAREST if hasattr(Image,'Resampling') else Image.NEAREST).convert('L')
            qr.save(str(self.cache/'share.png'))
            canvas=Image.new('L',(600,500),255);canvas.paste(qr,((600-size)//2,(500-size)//2));(self.cache/'share.raw').write_bytes(canvas.tobytes())
        return dict(result,image=str(self.cache/'share.raw'))

    def export(self, request):
        if not self.settings()['allow_exports']:raise ValueError('Enable file export in Settings first.')
        song = self.find_song(request['language'], request['number'])
        if not song: raise ValueError('Hymn not found')
        target_dir = Path(self.config.get('export_dir', '/mnt/us/documents/SDA Hymnal Exports'))
        target_dir.mkdir(parents=True, exist_ok=True)
        stem = song['number'] + '-' + re.sub(r'[^\w -]', '', song['title']).strip()
        if request.get('format') == 'lyrics':
            destination = target_dir/(stem+'.txt')
            destination.write_text(song['number']+' - '+song['title']+'\n\n'+lyrics_text(song), encoding='utf-8')
        else:
            rendered = self.render(dict(request, scope='share')); destination = target_dir/(stem+'-key-'+str(int(request.get('offset',0)))+'.pdf')
            shutil.copyfile(rendered['pdf'],str(destination))
        return dict(path=str(destination), message='Saved to Documents / SDA Hymnal Exports. Copy it by USB to share.')

    def protected(self):
        current = read_json(self.root/'current.json',{}); recovery = read_json(self.state/'recovery-app.json',{})
        entries = current.get('app',{}).get('files',[]) + current.get('data',{}).get('files',[]) + recovery.get('files',[])
        return {e['sha256'] for e in entries}, {i for i in [current.get('app',{}).get('id'),recovery.get('id')] if i}

    def storage(self):
        keep, app_ids = self.protected(); active = unused = rendered = 0
        for path in self.store.iterdir():
            if path.is_file():
                if path.name in keep: active += path.stat().st_size
                else: unused += path.stat().st_size
        for path in (self.cache/'scores').rglob('*'):
            if path.is_file(): rendered += path.stat().st_size
        return dict(saved_bytes=active, unused_bytes=unused, rendered_bytes=rendered,
                    selection=self.current.get('data',{}).get('selection'), settings=self.settings(),
                    app_version=self.current.get('app',{}).get('version', VERSION), data_version=self.current.get('data',{}).get('version','Unknown'))

    def _cleanup(self):
        current = read_json(self.root/'current.json',{})
        if not current or not all(self.have(e) for e in current.get('app',{}).get('files',[])+current.get('data',{}).get('files',[])):
            return dict(removed=0, message='Cleanup skipped because the saved hymnal is incomplete.')
        keep, app_ids = self.protected(); removed=0
        for path in self.store.iterdir():
            if path.is_file() and path.name not in keep: path.unlink(); removed+=1
        for path in self.releases.iterdir():
            if path.is_dir() and path.name not in app_ids: shutil.rmtree(str(path))
        return dict(removed=removed, message='Unused files removed. Current and recovery files were kept.')

    def cleanup(self):
        with self.lock(): return self._cleanup()

    def status(self):
        return dict(settings=self.settings(), storage=self.storage(), update=read_json(self.state/'check.json',{}),
                    app_version=self.current.get('app',{}).get('version',VERSION),
                    data_version=self.current.get('data',{}).get('version','Unknown'))

    def dispatch(self, request):
        command = request.get('command')
        actions = dict(status=lambda:self.status(), search=lambda:self.search(request), hymn=lambda:self.hymn(request),
                       settings=lambda:self.save_settings(request.get('changes',{})), check=self.check,
                       download=lambda:self.download(request.get('refresh',True)), render=lambda:self.render(request),
                       share=lambda:self.share(request), qr=lambda:self.qr(request), display=lambda:self.display(request), export=lambda:self.export(request), storage=self.storage, cleanup=self.cleanup)
        if command not in actions: raise ValueError('Unknown app command')
        return actions[command]()

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--root',required=True); parser.add_argument('--app-dir')
    parser.add_argument('--request',required=True); parser.add_argument('--response',required=True); args=parser.parse_args()
    response=Path(args.response)
    def progress(message,percent): atomic_json(response,dict(done=False,message=message,percent=percent))
    try:
        request=read_json(args.request)
        if not isinstance(request,dict): raise ValueError('Invalid request')
        if request.get('command') in ('render','export'):render_limits()
        result=Hymnal(args.root,args.app_dir,progress).dispatch(request)
        atomic_json(response,dict(done=True,ok=True,result=result))
    except Exception as error:
        atomic_json(response,dict(done=True,ok=False,error=str(error)))
        return 1
    return 0
if __name__=='__main__': raise SystemExit(main())
