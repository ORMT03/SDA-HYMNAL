#!/usr/bin/env python3
"""Stable launcher helper; application updates live in separate version directories."""
import json
import os
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
current=json.loads((root/'current.json').read_text())
app=root/'releases'/current['app']['id']
if not (app/'bin/hymnal').is_file() or not (app/'backend.py').is_file():
    recovery=root/'state/recovery-app.json'
    if not recovery.is_file(): raise SystemExit('The app is incomplete. Copy the Kindle install ZIP again.')
    current['app']=json.loads(recovery.read_text());app=root/'releases'/current['app']['id']
    if not (app/'bin/hymnal').is_file() or not (app/'backend.py').is_file():
        raise SystemExit('Native app incomplete. Recopy the installer.')
    temp=root/'current.json.recovery';temp.write_text(json.dumps(current));os.replace(str(temp),str(root/'current.json'))
print(str(app))
